import discord
from discord.ext import commands
from discord import app_commands
import logging
import asyncio
import random
import sqlite3
from PIL import Image, ImageDraw, ImageFont
import io
import aiohttp

# Настройка логирования
logging.basicConfig(filename="messages.log",
                    level=logging.INFO,
                    format="%(asctime)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")

# Настройка бота
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.guilds = True
intents.guild_messages = True
intents.voice_states = True
intents.members = True
bot = commands.Bot(command_prefix="/", intents=intents)

# Настройка базы данных
def db_setup():
    conn = sqlite3.connect('xp_database.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            xp INTEGER DEFAULT 0,
            level INTEGER DEFAULT 1
        )
    ''')
    conn.commit()
    conn.close()
    print("sql work great naxyi.")

# Функция для добавления XP
async def add_xp(user_id, amount):
    conn = sqlite3.connect('xp_database.db')
    c = conn.cursor()
    c.execute('INSERT OR IGNORE INTO users (user_id) VALUES (?)', (user_id, ))
    c.execute('UPDATE users SET xp = xp + ? WHERE user_id = ?', (amount, user_id))

    # Увеличение уровня, если XP превышает порог
    c.execute('SELECT xp, level FROM users WHERE user_id = ?', (user_id, ))
    xp, level = c.fetchone()
    if xp >= level * 100:
        level += 1
        c.execute('UPDATE users SET level = ? WHERE user_id = ?', (level, user_id))
        await bot.get_channel(TARGET_CHANNEL_ID).send(f"{bot.get_user(user_id).mention} достиг уровня {level}!")

    conn.commit()
    conn.close()
    print(f"Добавлено {amount} XP для пользователя {user_id}. Текущий XP: {xp + amount}, Уровень: {level}")

# Получение данных пользователя
def get_user_data(user_id):
    conn = sqlite3.connect('xp_database.db')
    c = conn.cursor()
    c.execute('SELECT xp, level FROM users WHERE user_id = ?', (user_id, ))
    data = c.fetchone()
    conn.close()
    return data if data else (0, 1)

# Загрузка аватара
async def fetch_avatar(avatar_url):
    async with aiohttp.ClientSession() as session:
        async with session.get(avatar_url) as response:
            return await response.read()

# Генерация изображения уровня
async def generate_level_image(user_id, user_name, avatar_url):
    xp, level = get_user_data(user_id)
    next_level_xp = level * 100
    progress_percentage = min(xp / next_level_xp, 1)

    # Размеры изображения
    width, height = 800, 200

    # Фон
    img = Image.new("RGB", (width, height), color=(40, 40, 40))
    d = ImageDraw.Draw(img)

    # Круг для аватара
    circle_radius = 50
    circle_x, circle_y = 20, height // 3 - circle_radius

    avatar = Image.open(io.BytesIO(await fetch_avatar(avatar_url)))
    avatar = avatar.resize((circle_radius * 2, circle_radius * 2))
    img.paste(avatar, (circle_x, circle_y))

    # Шрифты
    font_large = ImageFont.truetype('Comfortaa-VariableFont_wght.ttf', 40)
    font_small = ImageFont.truetype('Comfortaa-VariableFont_wght.ttf', 40)

    text_x = circle_x + circle_radius * 2 + 20
    text_y = circle_y + 5

    d.text((text_x, text_y + 5), f"{user_name} | Уровень {level}", font=font_large, fill=(255, 255, 255))
    d.text((text_x, text_y + 55), f"XP: {xp}/{next_level_xp}", font=font_small, fill=(255, 255, 255))

    # Полоса прогресса
    bar_width, bar_height = 750, 30
    bar_x, bar_y = 20, height - 60
    filled_width = int(bar_width * progress_percentage)

    d.rounded_rectangle([bar_x, bar_y, bar_x + bar_width, bar_y + bar_height], radius=15, fill=(200, 200, 200))
    d.rounded_rectangle([bar_x, bar_y, bar_x + filled_width, bar_y + bar_height], radius=15, fill=(255, 165, 0))

    byte_io = io.BytesIO()
    img.save(byte_io, 'PNG')
    byte_io.seek(0)

    return byte_io

# Константы
TARGET_CHANNEL_ID = 1324438108183466046
VOICE_CHANNEL_NOTIFICATION_ID = 1324443284310982676
MUTE_ROLE_ID = 1324449149223178291
ADMIN_ROLE_ID = 1168187028563824680

# Функция для проверки наличия роли администратора
def has_admin_role(interaction: discord.Interaction) -> bool:
    return any(role.id == ADMIN_ROLE_ID for role in interaction.user.roles)

# Событие on_ready
@bot.event
async def on_ready():
    await bot.tree.sync()  # Синхронизация команд
    activity = discord.Game(name="Jägermeister")
    await bot.change_presence(activity=activity)
    print(f"{bot.user.name} подключилась к дс")

# Событие on_message
@bot.event
async def on_message(message):
    if message.author.bot:
        return

    log_message = f"[{message.guild.name} - #{message.channel.name}] {message.author.name}: {message.content}"
    logging.info(log_message)

    target_channel = bot.get_channel(TARGET_CHANNEL_ID)
    if target_channel:
        embed = discord.Embed(title="нью сообщение", description=message.content, color=discord.Color.blue())
        embed.set_author(name=message.author.name, icon_url=message.author.avatar.url)
        embed.add_field(name="канал", value=f"#{message.channel.name}", inline=False)
        embed.set_footer(text=f"ID чела: {message.author.id}")
        await target_channel.send(embed=embed)

    await add_xp(message.author.id, random.randint(5, 15))
    await bot.process_commands(message)

# Событие on_voice_state_update
@bot.event
async def on_voice_state_update(member, before, after):
    notification_channel = bot.get_channel(VOICE_CHANNEL_NOTIFICATION_ID)
    if notification_channel:
        if before.channel is None and after.channel is not None:
            embed = discord.Embed(
                title="нью заход в войс",
                description=f"{member.name} зашел в войс: {after.channel.name}",
                color=discord.Color.green()
            )
            await notification_channel.send(embed=embed)
        elif before.channel is not None and after.channel is None:
            embed = discord.Embed(
                title="нью выход из войса",
                description=f"{member.name} вышел из войса: {before.channel.name}",
                color=discord.Color.red()
            )
            await notification_channel.send(embed=embed)
        elif before.channel != after.channel:
            embed = discord.Embed(
                title="нью переход из войса в войс",
                description=f"{member.name} перешел из {before.channel.name} в {after.channel.name}",
                color=discord.Color.blue()
            )
            await notification_channel.send(embed=embed)

# Команда /level
@bot.tree.command(name="level", description="Показывает ваш текущий уровень и XP")
async def level(interaction: discord.Interaction):
    user_id = interaction.user.id
    user_name = interaction.user.name
    avatar_url = interaction.user.avatar.url
    level_image = await generate_level_image(user_id, user_name, avatar_url)
    await interaction.response.send_message(file=discord.File(level_image, filename='level.png'))

# Команда /ping
@bot.tree.command(name="ping", description="Проверка работоспособности бота")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message("Pong!")

# Команда /roll
@bot.tree.command(name="roll", description="Бросает кубик с указанным количеством сторон")
@app_commands.describe(sides="Количество сторон кубика")
async def roll(interaction: discord.Interaction, sides: int = 6):
    if sides < 1:
        await interaction.response.send_message("Количество сторон должно быть положительным числом.")
        return
    result = random.randint(1, sides)
    await interaction.response.send_message(f"ты бросил кубик с {sides} сторонами и получили: **{result}**")

# Команда /vladosik
@bot.tree.command(name="vladosik", description="показывает какой мамонт крутой")
async def vladosik(interaction: discord.Interaction):
    await interaction.response.send_message(file=discord.File('vlados.png'))
    await interaction.followup.send("он очень крутой!")
    await interaction.followup.send("самый лучший")
    await interaction.followup.send("но лучше костика никого нету))))")

# Команда /quote
@bot.tree.command(name="quote", description="Показывает случайную цитату")
async def quote(interaction: discord.Interaction):
    quotes = [
        "Волк не тот кто волк, а тот кто волк", "Мирон долбаеб", "Артем долбаеб",
        "Соня свинья", "Агнесса дура АУФФФФФ",
        "Волк не тот кто даун, а тот кто волк", "Жизнь пиздатая вещь",
        "Get busy YEAT YA3 NAXYYYI", "Макан ван лав"
    ]
    quote = random.choice(quotes)
    await interaction.response.send_message(f"**Цитата:** {quote}")

# Команда /avatar
@bot.tree.command(name="avatar", description="Показывает аватар пользователя")
@app_commands.describe(member="Пользователь, чей аватар вы хотите увидеть")
async def avatar(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user
    embed = discord.Embed(title=f"аватар {member.name}", color=discord.Color.blue())
    embed.set_image(url=member.avatar.url)
    await interaction.response.send_message(embed=embed)

# Команда /serverinfo
@bot.tree.command(name="serverinfo", description="показывает информацию о сервере")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def serverinfo(interaction: discord.Interaction):
    guild = interaction.guild
    embed = discord.Embed(title=f"Информация о сервере: {guild.name}", color=discord.Color.green())
    embed.add_field(name="ID сервера", value=guild.id)
    embed.add_field(name="Создан", value=guild.created_at.strftime("%Y-%m-%d %H:%M:%S"))
    embed.add_field(name="Количество участников", value=guild.member_count)
    await interaction.response.send_message(embed=embed)

# Команда /userinfo
@bot.tree.command(name="userinfo", description="Показывает информацию о пользователе")
@app_commands.describe(member="Пользователь, информацию о котором вы хотите увидеть")
async def userinfo(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user
    embed = discord.Embed(title=f"Информация о пользователе: {member.name}", color=discord.Color.blue())
    embed.add_field(name="ID пользователя", value=member.id)
    embed.add_field(name="Создан", value=member.created_at.strftime("%Y-%m-%d %H:%M:%S"))
    embed.add_field(name="Присоединился", value=member.joined_at.strftime("%Y-%m-%d %H:%M:%S"))
    await interaction.response.send_message(embed=embed)

# Команда /say
@bot.tree.command(name="say", description="Отправляет сообщение от имени бота")
@app_commands.describe(message="Сообщение, которое вы хотите отправить")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def say(interaction: discord.Interaction, message: str):
    await interaction.response.send_message(message)

# Команда /clear
@bot.tree.command(name="clear", description="Удаляет указанное количество сообщений")
@app_commands.describe(amount="Количество сообщений для удаления")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def clear(interaction: discord.Interaction, amount: int):
    if amount <= 0:
        await interaction.response.send_message("Количество сообщений должно быть положительным числом.")
        return
    await interaction.channel.purge(limit=amount + 1)
    await interaction.response.send_message(f"Удалено {amount} сообщений.", delete_after=5)

# Команда /anons
@bot.tree.command(name="anons", description="Отправляет объявление")
@app_commands.describe(title="Заголовок объявления", message="Текст объявления")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def anons(interaction: discord.Interaction, title: str, message: str):
    embed = discord.Embed(title=title, description=message, color=discord.Color.red())
    await interaction.response.send_message(embed=embed)

# Команда /addxp
@bot.tree.command(name="addxp", description="Добавляет XP пользователю")
@app_commands.describe(member="Пользователь, которому нужно добавить XP", amount="Количество XP")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def addxp(interaction: discord.Interaction, member: discord.Member, amount: int):
    if amount <= 0:
        await interaction.response.send_message("Количество XP должно быть положительным числом.")
        return
    await add_xp(member.id, amount)
    await interaction.response.send_message(f"Добавлено {amount} XP пользователю {member.mention}.")

# Команда /mute
@bot.tree.command(name="mute", description="Мутит пользователя на указанное время")
@app_commands.describe(member="Пользователь, которого нужно замутить", time="Время в минутах", reason="Причина мута")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def mute(interaction: discord.Interaction, member: discord.Member, time: int, reason: str):
    role = interaction.guild.get_role(MUTE_ROLE_ID)
    if not role:
        await interaction.response.send_message("Роль для мута не найдена.")
        return

    await member.add_roles(role)
    embed = discord.Embed(
        title="чел замучен",
        description=f"{member.mention} был замучен на **{time} минут**. Причина: *{reason}*.",
        color=discord.Color.red()
    )
    await interaction.response.send_message(embed=embed)

    await asyncio.sleep(time * 60)
    await member.remove_roles(role)
    unmute_embed = discord.Embed(
        title="чел размучен",
        description=f"{member.mention} был размучен.",
        color=discord.Color.green()
    )
    await interaction.followup.send(embed=unmute_embed)

# Команда /unmute
@bot.tree.command(name="unmute", description="Снимает мут с пользователя")
@app_commands.describe(member="Пользователь, которого нужно размутить")
@app_commands.check(has_admin_role)  # Проверка роли администратора
async def unmute(interaction: discord.Interaction, member: discord.Member):
    role = interaction.guild.get_role(MUTE_ROLE_ID)
    if role:
        await member.remove_roles(role)
        embed = discord.Embed(
            title="Пользователь размучен",
            description=f"{member.mention} был размучен.",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)
    else:
        await interaction.response.send_message("Роль для мута не найдена.")

# Команда /ban
@bot.tree.command(name="ban", description="Банит пользователя")
@app_commands.describe(member="Пользователь, которого нужно забанить", reason="Причина бана")
@commands.has_permissions(ban_members=True)
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "Не указана причина."):
    try:
        await member.ban(reason=reason)
        embed = discord.Embed(
            title="Пользователь забанен",
            description=f"{member.mention} был забанен.\nПричина: *{reason}*.",
            color=discord.Color.red()
        )
        await interaction.response.send_message(embed=embed)
    except discord.Forbidden:
        await interaction.response.send_message("У меня нет прав, чтобы забанить этого пользователя.")
    except discord.HTTPException:
        await interaction.response.send_message("Не удалось забанить пользователя.")
    except Exception as e:
        await interaction.response.send_message(f"Произошла ошибка: {e}")

# Обработка ошибок для команд с проверкой роли
@bot.event
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        await interaction.response.send_message("У вас нет прав для использования этой команды.", ephemeral=True)
    else:
        raise error

# Запуск бота
db_setup()
bot.run('MTMyNDQ0MjAyODcwNDEzNzI1Ng.GdWlxb.UBCupsqI5Rbaoi_w08BuQZ_-cfCnDYBIWkJb6A')